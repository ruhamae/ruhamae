#!/usr/bin/env python3

import unittest
from shell_test_helpers import ShellTestCase  # Import ShellTestCase

SHELL = "./shell"  # Path to your shell executable

class ShellTests(ShellTestCase):
    def setUp(self):
        """Set up the shell command for the tests."""
        self.shell_command = SHELL

    def clean_output(self, output):
        """Remove any 'shell $' prompt from the start of each line in the output."""
        lines = output.splitlines()
        cleaned_lines = [line[7:].strip() if line.startswith("shell $") else line for line in lines]
        return "\n".join(cleaned_lines)

    def test_exit(self):
        """Test that the exit command works."""
        rc, actual = self.execute_shell(SHELL, input="exit\n")
        actual = self.clean_output(actual)
        self.assertIn("Bye bye.", actual)

    def test_single_echo(self):
        """Test that a single echo command works."""
        output = self.run_shell("echo one")
        output = self.clean_output(output)  # Clean output to remove any prompts
        self.assertEqual(output, "one")

    def test_two_commands(self):
        """Test that two commands work."""
        output = self.run_shell("echo one; echo two")
        output = self.clean_output(output)  # Clean output to remove any prompts
        self.assertEqual(output, "one\ntwo")

if __name__ == '__main__':
    unittest.main()
