#!/usr/bin/env python3

import sys
sys.path.append('./tests')  # Ensure the tests folder is in the Python path
from shell_test_helpers import sh  # Import only the sh function

from unittest import TestCase
import unittest

TOKENIZE = "./tokenize"

class TokenizeTests(TestCase):
    def test_simple_token(self):
        """Recognizes a simple non-special token"""
        self.assertEqual(sh("echo 'a' | ./tokenize"), 'a')

    def test_special_characters(self):
        """Recognizes special characters as tokens"""
        self.assertEqual(sh("echo '(;|)<>' | ./tokenize"), "(\n;\n|\n)\n<\n>")

if __name__ == '__main__':
    unittest.main()
