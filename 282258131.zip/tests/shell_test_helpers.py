import subprocess
from unittest import TestCase

class ShellTestCase(TestCase):
    def run_shell(self, inp):
        """Run a shell command with input."""
        rc, output = self.execute_shell(self.shell_command, input=inp)
        self.assertEqual(rc, 0)
        return self.filter_shell_output(output)

    def execute_shell(self, shell_command, input=None):
        """Execute a shell command."""
        try:
            proc_result = subprocess.run(shell_command, input=input, text=True, shell=True, capture_output=True)
            return proc_result.returncode, proc_result.stdout.strip()
        except Exception as e:
            print(f"Error: {e}")
            return 1, ""

    def filter_shell_output(self, output):
        """Filter and clean up shell output."""
        lines = output.splitlines()
        return "\n".join([line.strip() for line in lines if line.strip()])

# Helper function to run a simple command
def sh(command):
    return subprocess.run(command, shell=True, capture_output=True).stdout.decode().strip()
