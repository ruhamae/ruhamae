
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <errno.h>

#define MAX_INPUT_SIZE 1024
#define MAX_ARG_SIZE 64
#define HISTORY_SIZE 10

// Command history storage
char *history[HISTORY_SIZE];
int history_count = 0;

// Function prototypes
void execute_command(char *input);
void split_commands(char *input, char **commands);
void tokenize(char *command, char **args);
void handle_redirection_and_pipes(char *command);
void save_history(char *input);
void print_history();
void run_script(const char *path);

/**
 * Main shell loop: reads and executes commands.
 */
int main() {
    char input[MAX_INPUT_SIZE];

    while (1) {
        printf("shell $ ");
        if (!fgets(input, MAX_INPUT_SIZE, stdin)) break;
        input[strcspn(input, "\n")] = '\0'; // Remove newline

        if (strcmp(input, "exit") == 0) {
            printf("Bye bye.\n");
            break;
        }

        // Save to history
        save_history(input);

        // Execute commands
        execute_command(input);
    }

    return 0;
}

/**
 * Execute individual commands, handling pipes and sequences.
 */
void execute_command(char *input) {
    char *commands[MAX_ARG_SIZE];
    split_commands(input, commands);

    for (int i = 0; commands[i] != NULL; i++) {
        if (strcmp(commands[i], "prev") == 0) {
            print_history();
            continue;
        } else if (strncmp(commands[i], "source ", 7) == 0) {
            run_script(commands[i] + 7);
            continue;
        }

        handle_redirection_and_pipes(commands[i]);
    }
}

/**
 * Split input by ';' for command sequences.
 */
void split_commands(char *input, char **commands) {
    char *token;
    int index = 0;
    token = strtok(input, ";");
    while (token != NULL && index < MAX_ARG_SIZE - 1) {
        commands[index++] = token;
        token = strtok(NULL, ";");
    }
    commands[index] = NULL;
}

/**
 * Tokenize commands, respecting quotes.
 */
void tokenize(char *command, char **args) {
    int index = 0;
    char *start = command;
    while (*start) {
        while (isspace(*start)) start++;
        if (*start == '\0') break;

        if (*start == '"') {
            start++;
            args[index++] = start;
            while (*start && *start != '"') start++;
            if (*start) *start++ = '\0';
        } else {
            args[index++] = start;
            while (*start && !isspace(*start)) start++;
        }
        if (*start) *start++ = '\0';
    }
    args[index] = NULL;
}

/**
 * Handle pipes and redirection within a single command.
 */
void handle_redirection_and_pipes(char *command) {
    char *args[MAX_ARG_SIZE];
    tokenize(command, args);

    int pipes[MAX_ARG_SIZE][2];
    int cmd_count = 0;
    int i = 0;

    // Count commands in pipes and set up pipes array
    while (args[i]) {
        if (strcmp(args[i], "|") == 0) cmd_count++;
        i++;
    }
    cmd_count++;

    for (i = 0; i < cmd_count - 1; i++) {
        pipe(pipes[i]);
    }

    // Execute each command in the pipeline
    int j = 0;
    int cmd_idx = 0;
    while (args[j]) {
        char *cmd_args[MAX_ARG_SIZE];
        int arg_count = 0;
        
        while (args[j] && strcmp(args[j], "|") != 0) {
            cmd_args[arg_count++] = args[j++];
        }
        cmd_args[arg_count] = NULL;
        if (args[j]) j++; // Skip over "|"

        if (fork() == 0) {
            if (cmd_idx < cmd_count - 1) {
                dup2(pipes[cmd_idx][1], STDOUT_FILENO);
            }
            if (cmd_idx > 0) {
                dup2(pipes[cmd_idx - 1][0], STDIN_FILENO);
            }

            for (int k = 0; k < cmd_count - 1; k++) {
                close(pipes[k][0]);
                close(pipes[k][1]);
            }

            if (execvp(cmd_args[0], cmd_args) < 0) {
                perror("Exec failed");
                exit(1);
            }
        }
        cmd_idx++;
    }

    for (int i = 0; i < cmd_count - 1; i++) {
        close(pipes[i][0]);
        close(pipes[i][1]);
    }

    for (int i = 0; i < cmd_count; i++) {
        wait(NULL);
    }
}

/**
 * Save commands to history.
 */
void save_history(char *input) {
    if (history_count < HISTORY_SIZE) {
        history[history_count++] = strdup(input);
    } else {
        free(history[0]);
        for (int i = 1; i < HISTORY_SIZE; i++) {
            history[i - 1] = history[i];
        }
        history[HISTORY_SIZE - 1] = strdup(input);
    }
}

/**
 * Print command history.
 */
void print_history() {
    for (int i = 0; i < history_count; i++) {
        printf("%d: %s\n", i + 1, history[i]);
    }
}

/**
 * Run a script using source command.
 */
void run_script(const char *path) {
    FILE *file = fopen(path, "r");
    if (!file) {
        perror("Source file error");
        return;
    }

    char line[MAX_INPUT_SIZE];
    while (fgets(line, sizeof(line), file)) {
        line[strcspn(line, "\n")] = '\0'; // Remove newline
        execute_command(line);
    }
    fclose(file);
}