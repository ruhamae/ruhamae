#include <stdio.h>
#include <string.h>
#include <ctype.h>

#define MAX_INPUT_SIZE 256
#define MAX_TOKEN_SIZE 64

int is_special_token(char ch) {
    return ch == '(' || ch == ')' || ch == '<' || ch == '>' || ch == ';' || ch == '|';
}

int read_token(const char *input, char *output) {
    int i = 0;
    if (input[i] == '"') {
        ++i;
        while (input[i] != '\0' && input[i] != '"') {
            output[i - 1] = input[i];
            ++i;
        }
        output[i - 1] = '\0';
        return i + 1;
    } else if (is_special_token(input[i])) {
        output[0] = input[i];
        output[1] = '\0';
        return 1;
    } else {
        while (input[i] && !isspace(input[i]) && !is_special_token(input[i])) {
            output[i] = input[i];
            ++i;
        }
        output[i] = '\0';
        return i;
    }
}

void tokenize(const char *input) {
    char token[MAX_TOKEN_SIZE];
    int i = 0;
    int token_length;

    while (input[i]) {
        while (isspace(input[i])) {
            ++i;
        }
        if (input[i] == '\0') break;
        
        token_length = read_token(&input[i], token);
        i += token_length;

        if (token[0] != '\0') {
            printf("%s\n", token);  // Print token without any prefix
        }
    }
}

int main() {
    char input[MAX_INPUT_SIZE];
    if (fgets(input, MAX_INPUT_SIZE, stdin)) {
        input[strcspn(input, "\n")] = '\0';
        tokenize(input);
    }
    return 0;
}
